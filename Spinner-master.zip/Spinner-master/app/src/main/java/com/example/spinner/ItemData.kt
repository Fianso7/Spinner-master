package com.example.spinner

class ItemData(var name:String, var image: Int,var details:String) {

}